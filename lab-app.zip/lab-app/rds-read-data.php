<h2>Covid List</h2><p>
<?php
  //This is a simple address book example for testing with RDS

  include('rds.conf.php');


  // Set address book variables
  isset($_REQUEST['mode']) ? $mode=$_REQUEST['mode'] : $mode="";
  // isset($_REQUEST['id']) ? $id=$_REQUEST['id'] : $id="";
  isset($_REQUEST['day']) ? $day=$_REQUEST['day'] : $day="";
  // isset($_REQUEST['firstname']) ? $firstname=$_REQUEST['firstname'] : $firstname="";
  // isset($_REQUEST['phone']) ? $phone=$_REQUEST['phone'] : $phone="";
  // isset($_REQUEST['email']) ? $email=$_REQUEST['email'] : $email="";

  // Connect to the RDS database
  mysql_connect($RDS_URL, $RDS_user, $RDS_pwd) or die(mysql_error());

  mysql_select_db($RDS_DB) or die(mysql_error());
  $old = mysql_query("SELECT * FROM covid ORDER BY day DESC Limit 1");
 or die(mysql_error());
 while($days = mysql_fetch_array( $old ))
 {
  $begin = new DateTime( $days['day'] );
  $end   = date('Y-m-d');

  for($i = $begin; $i <= $end; $i->modify('+1 day')){
      // echo $i->format("Y-m-d");
      $file = file_get_contents("https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data/csse_covid_19_daily_reports/".$i->format("m-d-Y").".csv");
      $rows = explode("\n",$file);
      $c = 0;
      $d = 0;
      $r = 0;
      // $s = array();
      foreach($rows as $row) {
        $s = str_getcsv($row);
        $c = $c + (int)$s[7];
        $d = $d + (int)$s[8];
        $r = $r + (int)$s[9];
      }
      mysql_query("INSERT INTO covid (day, confirm, death, recovered) VALUES ('".$i->format("Y-m-d")."', ".$c.", ".$d.", ".$r.");")
  }
 }
// if ( $mode=="add")
//  {
 Print '<h2>Select Day</h2>
 <p>
 <form action=';
 echo $_SERVER['PHP_SELF'];
 Print '
 method=post>
 <table>
 <tr><td>Day:</td><td><input type="date" name="day" /></td></tr>
 <tr><td colspan="2" align="center"><input type="submit" /></td></tr>
 <input type=hidden name=mode value=added>
 </table>
 </form> <p>';
//  }

//  if ( $mode=="added")
//  {
//  mysql_query ("SELECT * FROM covid");
//  }

// if ( $mode=="edit")
//  {
//  Print '<h2>Edit Contact</h2>
//  <p>
//  <form action=';
//  echo $_SERVER['PHP_SELF'];
//  Print '
//  method=post>
//  <table>
//  <tr><td>Last name:</td><td><input type="text" value="';
//  Print $lastname;
//  print '" name="lastname" /></td></tr>
//  <tr><td>First name:</td><td><input type="text" value="';
//  Print $firstname;
//  print '" name="firstname" /></td></tr>
//  <tr><td>Phone:</td><td><input type="text" value="';
//  Print $phone;
//  print '" name="phone" /></td></tr>
//  <tr><td>Email:</td><td><input type="text" value="';
//  Print $email;
//  print '" name="email" /></td></tr>
//  <tr><td colspan="3" align="center"><input type="submit" /></td></tr>
//  <input type=hidden name=mode value=edited>
//  <input type=hidden name=id value=';
//  Print $id;
//  print '>
//  </table>
//  </form> <p>';
//  }

//  if ( $mode=="edited")
//  {
//  mysql_query ("UPDATE address SET lastname = '$lastname', firstname = '$firstname', phone = '$phone', email = '$email' WHERE id = $id");
//  Print "Data Updated!<p>";
//  }

// if ( $mode=="remove")
//  {
//  mysql_query ("DELETE FROM address where id=$id");
//  Print "Entry has been removed <p>";
//  }
if ( $mode=="added"){
 $data = mysql_query("SELECT * FROM covid WHERE day=".$day)
 or die(mysql_error());
}
 Print "<table border cellpadding=3>";
 Print "<tr><th width=100>Day</th> " .
   "<th width=100>Confirm</th> " .
   "<th width=100>Death</th> " .
   "<th width=100>Recovered</th></tr>";
//  Print "<td colspan=6 align=right> " .
  //  "<a href=" .$_SERVER['PHP_SELF']. "?mode=add>Add Contact</a></td>";

 while($info = mysql_fetch_array( $data ))
 {
 Print "<tr><td>".$info['day'] . "</td> ";
 Print "<td>".$info['confirm'] . "</td> ";
 Print "<td>".$info['death'] . "</td> ";
 Print "<td>".$info['recovered'] . "</td></tr> ";
//  Print "<td> <a href=mailto:".$info['email'] . ">" .$info['email'] . "</a></td>";
//  Print "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&lastname=" . $info['lastname'] . "&firstname=" . $info['firstname'] . "&phone=" . $info['phone'] ."&email=" . $info['email'] . "&mode=edit>Edit</a></td>";
//  Print "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&mode=remove>Remove</a></td></tr>";
 }
 Print "</table>";

?>
